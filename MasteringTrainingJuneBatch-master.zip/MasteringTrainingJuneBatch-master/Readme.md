
# Mastering CI June 16 batch.

This is demo code. 
1. Identify test cases.
2. Mock the repository object using Mockito
3. Configure maven